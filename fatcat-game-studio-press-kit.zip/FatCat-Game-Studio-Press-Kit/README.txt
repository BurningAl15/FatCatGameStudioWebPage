FATCAT GAME STUDIO — PRESS KIT

This package contains the studio logos and all public game images used by the studio website.
Assets are grouped under assets/; game screenshots and artwork are in assets/games/<game-slug>/.
For descriptions, platforms, links and current press information, visit:
https://burningal15.github.io/FatCatGameStudioWebPage/press/

KIT DE PRENSA — FATCAT GAME STUDIO

Este paquete incluye los logos del estudio y todas las imágenes públicas de los juegos que aparecen en su web.
Los recursos están en assets/; las capturas y artes se agrupan en assets/games/<slug-del-juego>/.
Descripciones, plataformas y enlaces actualizados:
https://burningal15.github.io/FatCatGameStudioWebPage/es/prensa/

Contact: fatcatgamestudio.oc@gmail.com